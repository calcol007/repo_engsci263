import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import differential_evolution
from scipy.integrate import solve_ivp
from scipy import optimize
from numpy.linalg import solve
from math import exp

# functions related to interpolation using cubic splines
###########################################################################################

def spline_coefficient_matrix(xi):    
    ''' 
    Evaluates a polynomial.
        
        Parameters
        ----------
        xi : array-like
             Array of subinterval boundaries 

        Returns
        -------
        A : array-like
            Coefficient matrix 

        Notes
        -----
        Subinterval boundary points, xi, assumed to be in ascending order.

    '''
    # get number of subinterval boundary points
    N = len(xi)

    # initialise matrix of zeros
    A = np.zeros((4*(N-1), 4*(N-1)))

    # populating matrix with respective values
    for i in np.arange(0, (2*N-3), 2):
        A[i, 0 + 2*i] = 1
        
    for i in np.arange(1, (2*N-2), 2):
        A[i, 0 + 2*(i-1)] = 1
        A[i, 1 + 2*(i-1)] = (xi[int(0.5*(i-1) + 1)] - xi[int(0.5*(i-1))])
        A[i, 2 + 2*(i-1)] = (xi[int(0.5*(i-1) + 1)] - xi[int(0.5*(i-1))])**2
        A[i, 3 + 2*(i-1)] = (xi[int(0.5*(i-1) + 1)] - xi[int(0.5*(i-1))])**3

    # do not include derivative equations if only two boundaries
    if N != 2:
        for i in np.arange(2*N-2, (2*N-2) + 2*(N-3) + 1, 2):
            v = int(0.5*(i - 2*(N-1)))
            A[i, 1 + 2*(i - 2*(N-1))] = 1
            A[i, 2 + 2*(i - 2*(N-1))] = 2*(xi[v+1] - xi[v])
            A[i, 3 + 2*(i - 2*(N-1))] = 3*((xi[v+1] - xi[v])**2)
            A[i, 5 + 2*(i - 2*(N-1))] = -1
            
        for i in np.arange(2*N-1, (2*N-1) + 2*(N-3) + 1, 2):
            u = int(0.5*(i - 1 - 2*(N-1)))
            A[i, 2 + 2*(i - 1 - 2*(N-1))] = 2
            A[i, 3 + 2*(i - 1 - 2*(N-1))] = 6*(xi[u+1] - xi[u])
            A[i, 6 + 2*(i - 1 - 2*(N-1))] = -2
        
    A[4*(N-1)-2, 2] = 2
    A[4*(N-1)-1, 4*(N-1)-2] = 2
    A[4*(N-1)-1, 4*(N-1)-1] = 6*(xi[N-1] - xi[N-2])
        
    return A



def spline_rhs(xi, yi):
    ''' 
    Evaluates a polynomial.
        
        Parameters
        ----------
        xi : array-like
             Array of subinterval boundaries
        
        yi : array-like
             Array of dependent variable values at respective subinterval boundaries

        Returns
        -------
        rhs : array-like
              Vector of right-hand-side matrix equation
    
        Notes
        -----
        Subinterval boundary points, xi, assumed to be in ascending order.

    '''
    # get number of evaluated points
    N = len(yi)

    # initialise rhs vector
    rhs = np.zeros(4*(N-1))

    # populating the rhs vector
    rhs[:2*(N-1):2] = yi[:N-1]
    rhs[1:2*(N-1):2] = yi[1:]

    return rhs
    


def spline_interpolate(xj, xi, ak):
    ''' 
    Return a set of interpolated values.
        
        Parameters
        ----------
        xj : array-like
             Array of points for interpolation

        xi : array-like
             Array of subinterval boundaries 

        ak : array-like
             Vector of spline polynomial coefficients     
        
        Returns
        -------
        yj : array-like
             Array of interpolated values at the given xj (interpolating) points
    
        Notes
        -----
        Interpolation points, xj, assumed to be in ascending order.

    '''
    # get number of subinterval boundaries and interpolation points
    N = len(xi)
    M = len(xj)
    # initialise j counter to 0
    j = 0
    # initialise numpy array for yj
    yj = np.zeros(M)

    # loop over intervals
    for i in range(N-1):
        # get spline coefficients 
        coef = ak[4*i: 4*(i+1)]
        # while loop to compute dot product of correct values and coefficients
        while j < M and xj[j] >= xi[i] and xj[j] < xi[i+1]:
            yj[j] = np.dot(coef, [1, (xj[j] - xi[i]), (xj[j] - xi[i])**2, (xj[j] - xi[i])**3])
            j += 1
            
    return yj



def polyval(a,xi):
    ''' 
    Evaluates a polynomial.
        
        Parameters
        ----------
        a : np.array
            Vector of polynomial coefficients.
        xi : np.array
            Points at which to evaluate polynomial.
        
        Returns
        -------
        yi : np.array
            Evaluated polynomial.
            
        Notes
        -----
        Polynomial coefficients assumed to be increasing order, i.e.,
        
        yi = Sum_(i=0)^len(a) a[i]*xi**i
        
    '''
    # initialise output at correct length
    yi = 0.*xi
    
    # loop over polynomial coefficients
    for i,ai in enumerate(a):
        yi = yi + ai*xi**i
        
    return yi



# functions related to the data and solving of the ODEs
###########################################################################################

def readInData():
    '''
    This function reads in the data of the number of cows and nitrate levels over the years.
        
        Parameters:
        -----------
        None

        Returns:
        --------
        ts: array-like
            Years over which the cows were counted.
        stock: array-like
            Number of cows over the years.
        ts1: array-like
            Years over which the nitrate levels were counted.
        lvls: array-like
            Nitrate levels over the years.

    '''
    ts, stock = np.genfromtxt("nl_cows.txt", delimiter = ",", skip_header = 1, unpack = True)
    ts1, lvls = np.genfromtxt("nl_n.csv", delimiter = ",", skip_header = 1, unpack = True)

    return ts, stock, ts1, lvls



def sum_of_squares(pars, ts1, lvls, c0, tau, ts, ak, tc, alpha, b1, PMAR, Psurf, Pa): 
    ''' 
    Find the sum of squares at each data point.

        Parameters:
        -----------
        pars : array-like
            Array of parameters. Pars = [b, bc, P0, M0]
        ts1: array-like
            Years over which the nitrate levels were counted.
        lvls : array-like
            Nitrate levels over the years.
        tau : float
            Nitrate leaching time delay
        ts: array-like
            Years over which the cows were counted.
        ak : array-like
            Vector of spline polynomial coefficients 
        tc : float
            Year when carbon sink initiative implemented.
        alpha : float
            Parameter indicating successfulness of carbon sink initiative.
        b1 : float
            Parameter indicating strength of nitrate infiltration into groundwater.
        PMAR : float
            Change in pressure introduce from MAR initiative. 
        Psurf : float
            Surface overpressure driving nitrate leaching 
        Pa : float
            Pressure drop across the aquifer.

        Returns:
        --------
        float
            value of the sum of squares

    '''
    # Solve ode using LSODA algorithm 
    c = solve_ivp(ode_model_concentration, [ts1[0], ts1[-1]], [c0], "LSODA", t_eval=ts1, args=[pars, tau, ts, ak, tc, alpha, b1, ts1[0], ts1[-1], PMAR, Psurf, Pa])
    return np.sum(np.square(c.y[0] - lvls))  # calculate and return sum of squares



def pressure(t, t0, P0, b, tMAR, PMAR):
    ''' 
    Evaluates pressure values at given times, t.

        Parameters:
        -----------
        t : array-like
            Array of times at which to evaluate pressure.
        t0 : float
            Initial time of solution.
        P0 : float
            Unknown initial pressure within the aquifer.
        b : float
            Unknown parameter.
        tMAR : float
            Year when MAR initiative is implemented.
        
        PMAR : float
            Change in pressure introduce from MAR initiative. 

        Returns:
        --------
        array-like
            Array of pressure values at given times, t.
        
        Notes
        -----
        depends on whether MAR initiative implemented or not

    '''
    if t <= tMAR:
        return P0 * exp(-2*b*t) # analytical solution if MAR initiative not yet implemented
    return (P0-PMAR/4)*exp(-2*b*t) + PMAR/4 # analytical solution if MAR initiative has been implemented



def b_dash(t, tc, alpha, b1):
    ''' 
    Evaluates b_dash array to be passed into ode_model_concentration.

        Parameters:
        -----------
        t : array-like
            Array of times at which to evaluate concentration.
        tc : float
            Year when carbon sink initiative implemented.
        alpha : float
            Parameter indicating successfulness of carbon sink initiative.
        b1 : float
            Parameter indicating strength of nitrate infiltration into groundwater.

        Returns:
        --------
        array-like
            Array of values of b_dash depending on carbon sink initiative implementation.

    '''
    if t < tc:
        return b1  # if carbon sink not yet installed
    return alpha * b1  # if carbon sink installed



def fittingModel(t, stock_no):
    '''
        This function takes two arrays for t and c and guesses parameters from an equation into it.
        
        Parameters:
        -----------
        t: Array like
            independent variable array
        stock_no: Array like
            dependent variable array
        
         Returns:
        --------
        params: array-like
            array for the parameter guesses
        covar: array-like
            array for the covariance guesses
    '''
    return optimize.curve_fit(future_cattle_model, t, stock_no)



def future_cattle_model(t, a, b):
    '''
        This function returns the model associated with cattle stock growth in the future.
        
        Parameters:
        -----------
        a: float
            parameter for linear equation
        b: float
            parameter for linear equation
        
         Returns:
        --------
        array-like
            array for cow valuesa at given time values
        
    '''
    return  a*t + b



def n_stock(t, ts, ak):
    ''' 
    Evaluates n_stock array to be passed into ode_model_concentration.

        Parameters:
        -----------
        t : array-like
            Array of times at which to evaluate concentration.
        ts: array-like
            Years over which the cows were counted.
        ak : array-like
            Vector of spline polynomial coefficients 

        Returns:
        --------
        array-like
            Array of cattle stock numbers at given times, t.

    '''
    stock = readInData()[1]
    if t <= ts[-1]:
        i = np.searchsorted(ts, t) - 1
        if i == -1:
            return 37772  # number of cattle stock asssumed to be present before 1990
        elif i == len(ts) - 1:
            t  = ts[-1]
        return polyval(ak[4*i:4*(i+1)], t-ts[i])  # cattle stock numbers using interpolation of data points
    else:
        return future_cattle_model(t, *fittingModel(ts, stock)[0])  # future cattle stock model

    

def ode_model_concentration(t, c, pars, tau, ts, ak, tc, alpha, b1, t0, tMAR, PMAR, Psurf, Pa):
    '''     
    ODE model for concentration which is to be solved.

        Parameters:
        -----------
        t : array-like
            Array of times at which to evaluate concentration.
        c : array-like
            Array of concentrations.
        pars : array-like
            Array of parameters. Pars = [b, bc, P0, M0]
        tau : float
            Nitrate leaching time delay
        ts: array-like
            Years over which the cows were counted.
        ak : array-like
            Vector of spline polynomial coefficients 
        tc : float
            Year when carbon sink initiative implemented.
        alpha : float
            Parameter indicating successfulness of carbon sink initiative.
        b1 : float
            Parameter indicating strength of nitrate infiltration into groundwater.
        t0 : float
            Initial time of solution.
        tMAR : float
            Year when MAR initiative is implemented.
        PMAR : float
            Change in pressure introduce from MAR initiative. 
        Psurf : float
            Surface overpressure driving nitrate leaching 
        Pa : float
            Pressure drop across the aquifer.
       
        Returns:
        --------
        float
            Value of ode model

    '''
    b, bc, P0, M0 = pars
    if t <= tMAR:
        return (-n_stock(t-tau, ts, ak)*b_dash(t-tau, tc, alpha, b1)*(pressure(t, t0, P0, b, tMAR, PMAR) - Psurf) + bc*(pressure(t, t0, P0, b, tMAR, PMAR) - Pa/2)*c) / M0  # ODE model before tMAR
    return (-n_stock(t-tau, ts, ak)*b_dash(t-tau, tc, alpha, b1)*(pressure(t, t0, P0, b, tMAR, PMAR) - Psurf) + bc*(pressure(t, t0, P0, b, tMAR, PMAR) - (Pa+PMAR)/2)*c) / M0  # ODE model after tMAR



# main function to run functions and output results
###########################################################################################

def main():
    
    # read in the data from the txt files
    ts, stock, ts1, lvls = readInData()

    # plot the interpolated cattle stock data
    f, ax1 = plt.subplots(1,1)
    ax1.plot(ts, stock, 'ro', label = "cattle data")
    A = spline_coefficient_matrix(ts)
    b = spline_rhs(ts,stock)
    ak = solve(A,b)
    label = "interpolated"
    stockArr = np.zeros(606)
    # run the interpolation functions and plotting
    for i, ti1, ti2 in zip(range(len(ts)-1), ts[:-1], ts[1:]):
        tv = np.linspace(ti1,ti2,101)
        stockv = polyval(ak[4*i:4*(i+1)], tv-ti1)
        ax1.plot(tv,stockv,'r-',label=label)
        label = None
        for value in stockv:
            stockArr = np.append(stockArr, value)
    ax1.set_xlabel("time [years]")
    ax1.set_ylabel("no. cows")
    plt.title('Interpolation of Cattle Stock Data Points')
    ax1.legend()
    
    savePlot = False  # set to True to save the plot as 'interpolation.png'
    if savePlot:
        plt.savefig('interpolation.png')   
    else:
        plt.show()


    # plot the data with concentration best-fit
    f1, ax1 = plt.subplots(1, 1)
    ax2 = ax1.twinx()
    # bounds = [[0, 1000], [1, 5], [0, 1000], [0.75, 1.25]]  # bounds to search for parameter values
    bounds = [[24.01595224, 24.01595224], [3.12086543, 3.12086543], [414.17187084, 414.17187084], [0.89568477, 0.89568477]]  # bounds to search for parameter values
    args = [ts1, lvls, 0.2, 2, ts, ak, 2010, 0.3, 1e-4, 0, 0.05, 0.1]
    res = differential_evolution(sum_of_squares, bounds, args, seed = 20000, disp = False)  # get optimized parameter values

    t_range = [1980, 2019.5]
    t_preMAR = [1980, 2019.5]
    c = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:])

    title = "Solved Nitrate Concentration ODE Model and Data\n [b, bc, P0, M0] = " + str(res.x)

    ax1.plot(ts, stock, 'ro', label = "cattle data points")
    ax2.plot(ts1, lvls, 'ko', label = "concentration data points")
    ax2.plot(c.t, c.y[0], 'k-', label = "nitrate concentration best fit")
    ax1.set_xlabel("time [years]")
    ax1.set_ylabel("no. cows")
    ax2.set_ylabel("nitrate concentration [mg/L]")
    plt.title(title)
    ax2.legend(loc='upper left')
    ax1.legend(loc='upper right')

    savePlot = False  # set to True to save the plot as 'best_fit.png'
    if savePlot:
        plt.savefig('best_fit.png')   
    else:
        plt.show()


    # plot the future cattle model
    f1, ax1 = plt.subplots(1, 1)
    ax2 = ax1.twinx()
    t = np.linspace(ts[0], 2050, 1000)
    ax1.plot(ts, stock, 'ro', label = "cattle data")
    ax1.plot(t, future_cattle_model(t, *fittingModel(ts, stock)[0]), 'k-', label = "best fit")
    ax1.set_xlabel("time [years]")
    ax1.set_ylabel("no. cows")
    ax1.legend()
    plt.title("Future Cattle Stock Model")

    savePlot = False  # set to True to save the plot as 'best_fit.png'
    if savePlot:
        plt.savefig('future_cattle_model.png')   
    else:
        plt.show()

    
    # plot the misfit
    f1, ax1 = plt.subplots(1, 1)

    # linear interpolation to calculate misfit
    c_misfit = []
    for i in range(0, len(ts1)):
        j = 0
        while c.t[j] <= ts1[i]:
            j = j+1
        m = (c.y[0][j]-c.y[0][j-1])/(c.t[j]-c.t[j-1])
        c_misfit.append((m*ts1[j-1] + (c.y[0][j-1]-(m*c.t[j-1])))-lvls[i])
    
    ax1.plot(ts1, c_misfit, 'rx', label = "misfit")
    plt.axhline(y=0.0, color='k', linestyle=':')
    ax1.set_xlabel("time [years]")
    ax1.set_ylabel("concentration misfit [mg/L]")
    plt.title("Misfit for Solved Nitrate Concentration ODE Model")
    
    savePlot = False  # set to True to save the plot as ''misfit.png'
    if savePlot:
        plt.savefig('misfit.png')   
    else:
        plt.show()


    # plot forward modelling
    f1, ax1 = plt.subplots(1, 1)
    ax2 = ax1.twinx()

    t_range = [2019.5, 2050]
    args[2] = c.y[0][-1]
    args[9] = 0.00
    c_0 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.00

    args[9] = 0.02
    c_1 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.02

    args[9] = 0.05
    c_2 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.05

    args[9] = 0.075
    c_3 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.075

    args[9] = 0.1
    c_4 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.1

    ax1.plot(ts, stock, 'ro', label = "cattle data points")
    ax2.plot(ts1, lvls, 'ko', label = "concentration data points")
    ax2.plot(c.t, c.y[0], 'k-', label = "nitrate concentration best fit")
    ax2.plot(c_0.t, c_0.y[0], 'c-', label = "PMAR = 0.00")
    ax2.plot(c_1.t, c_1.y[0], 'g-', label = "PMAR = 0.02")
    ax2.plot(c_2.t, c_2.y[0], 'r-', label = "PMAR = 0.05")
    ax2.plot(c_3.t, c_3.y[0], 'b-', label = "PMAR = 0.075")
    ax2.plot(c_4.t, c_4.y[0], 'm-', label = "PMAR = 0.1")
    ax2.axhline(y=8.475, color='k', linestyle=':', label = "Drinking Water Standard (NZDWS)\n 75% of Nitrate-MAV (Maximum Allowable Value)")
    ax1.set_xlabel("time [years]")
    ax1.set_ylabel("no. cows")
    ax2.set_ylabel("nitrate concentration [mg/L]")
    plt.title("Forward Modelling with Various MAR Schemes")
    ax2.legend(loc='upper left')
    ax1.legend(loc='upper right')

    savePlot = False  # set to True to save the plot as 'forward_modelling.png'
    if savePlot:
        plt.savefig('forward_modelling.png')   
    else:
        plt.show()


if __name__ == "__main__":
    main()
