from firstModel import dCdt

def unitTest():

    # this function will perform unit tests with the function dCdt

    # when manually calculated results 0
    C = dCdt(0, 0, [0, 0, 0, 1], 0, 0, 0, 0, 1, 1, 1, 1)
    assert(C == 0)

    # when manually calculated results -75544
    C = dCdt(0, 0, [0, -1, -1, 1], 0, 0, 0, -1, 1, 1, 1, 1)
    assert(C == -75544)

    # when manually calculated results 1
    C = dCdt(0, 1, [0, 1, 1, 1], 0, 0, 0, 0, 1, 0, 0, 1)
    assert(C == 1)

    print("Passed all unit tests.")


if __name__ == "__main__":
    unitTest()