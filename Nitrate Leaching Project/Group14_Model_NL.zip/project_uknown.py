from main import *
import matplotlib.pyplot as plt
import numpy as np
from math import exp
from scipy import optimize 
from statsmodels import multivariate

def grid_search():
    ''' This function implements a grid search to compute the posterior over b and bc.

		Returns:
		--------
		b : array-like
			Vector of 'b' parameter values.
		bc : array-like
			Vector of 'bc' parameter values.
		P : array-like
			Posterior probability distribution.
	'''    
    #load in the data
    ts, stock, ts1, lvls = readInData()
    A = spline_coefficient_matrix(ts)
    b = spline_rhs(ts,stock)
    ak = solve(A,b)
    bounds = [[24.01595224, 24.01595224], [3.12086543, 3.12086543], [414.17187084, 414.17187084], [0.89568477, 0.89568477]]  # bounds to search for parameter values
    args = [ts1, lvls, 0.2, 2, ts, ak, 2010, 0.3, 1e-4, 0, 0.05, 0.1]
    res = differential_evolution(sum_of_squares, bounds, args, seed = 20000, disp = False)  # get optimized parameter values
    pars = [res.x][0]
    t_range = [1980, 2019.5]
    t_preMAR = [1980, 2019.5]
    c = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:])
    for i in range(len(c.y[0])):
        var = lvls[i] - c.y[0][i]
	# define parameter ranges for the grid search
    b_best = pars[0]
    bc_best = pars[1]
	# number of values considered for each parameter within a given interval
    N = 50	

	# vectors of parameter values
    b = np.linspace(b_best/2,b_best*1.5, N)
    bc = np.linspace(bc_best/2,bc_best*1.5, N)

	# grid of parameter values: returns every possible combination of parameters in b and bc
    B, BC = np.meshgrid(b, bc, indexing='ij')

	# empty 2D matrix for objective function
    S = np.zeros(B.shape)

    # compute objective function for each combination of paramters b and bc
    for i in range(len(b)):
        for j in range(len(bc)):
            pars = [b[i], bc[j], pars[2], pars[3]]
            c = solve_ivp(ode_model_concentration, [ts1[0], ts1[-1]], [0.2], "LSODA", t_eval=ts1, args=[pars, 2, ts, ak, 2010, 0.3, 1e-4, ts1[0], ts1[-1], 0, 0.05, 0.1])
            S[i,j] = np.sum(np.square(c.y[0] - lvls))/var
	# compute the posterior
    P = np.exp(-S/2.)
    # normalize to a probability density function
    Pint = np.sum(P)*(b[1]-b[0])*(bc[1]-bc[0])
    P = P/Pint
    return b, bc, P

def fit_mvn(parspace, dist):
    """Finds the parameters of a multivariate normal distribution that best fits the data

    Parameters:
    -----------
        parspace : array-like
            list of meshgrid arrays spanning parameter space
        dist : array-like 
            PDF over parameter space
    Returns:
    --------
        mean : array-like
            distribution mean
        cov : array-like
            covariance matrix		
    """
    
    # dimensionality of parameter space
    N = len(parspace)
    
    # flatten arrays
    parspace = [p.flatten() for p in parspace]
    dist = dist.flatten()
    
    # compute means
    mean = [np.sum(dist*par)/np.sum(dist) for par in parspace]
    
    # compute covariance matrix
        # empty matrix
    cov = np.zeros((N,N))
        # loop over rows
    for i in range(0,N):
            # loop over upper triangle
        for j in range(i,N):
                # compute covariance
            cov[i,j] = np.sum(dist*(parspace[i] - mean[i])*(parspace[j] - mean[j]))/np.sum(dist)
                # assign to lower triangle
            if i != j: cov[j,i] = cov[i,j]
            
    return np.array(mean), np.array(cov)

def construct_samples(b,bc,P,N_samples):
	''' This function constructs samples from a multivariate normal distribution
	    fitted to the data.

		Parameters:
		-----------
		b : array-like
			Vector of 'b' parameter values.
		bc : array-like
			Vector of 'bc' parameter values.
		P : array-like
			Posterior probability distribution.
		N_samples : int
			Number of samples to take.

		Returns:
		--------
		samples : array-like
			parameter samples from the multivariate normal
	'''

	# fit the data using multivariate gaussain distribution
	B, BC = np.meshgrid(b,bc,indexing='ij')
	mean, covariance = fit_mvn([B,BC], P)

	# generate samples using multivariate normal function
	samples = np.random.multivariate_normal(mean, covariance, N_samples)

	return samples

def model_ensemble(samples):
    ''' Runs the model for given parameter samples and plots the results.

		Parameters:
		-----------
		samples : array-like
			parameter samples from the multivariate normal
	'''
    # read in data 
    ts, stock, ts1, lvls = readInData()
    A = spline_coefficient_matrix(ts)
    b = spline_rhs(ts,stock)
    ak = solve(A,b)
    bounds = [[24.01595224, 24.01595224], [3.12086543, 3.12086543], [414.17187084, 414.17187084], [0.89568477, 0.89568477]]  # bounds to search for parameter values
    args = [ts1, lvls, 0.2, 2, ts, ak, 2010, 0.3, 1e-4, 0, 0.05, 0.1]
    res = differential_evolution(sum_of_squares, bounds, args, seed = 20000, disp = False)  # get optimized parameter values

    t_range = [1980, 2019.5]
    t_preMAR = [1980, 2019.5]
    c = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[res.x]+args[3:-3]+t_preMAR+args[-3:])
    # calculate variance in parameters (observational error)
    for i in range(len(c.y[0])):
        var = lvls[i] - c.y[0][i]

    params = [res.x][0]

	# plot of best fit with uncertainty
    f1, ax1 = plt.subplots(1, 1)
    ax2 = ax1.twinx()

	# for each random sample solve and plot the model
    for b, bc in samples:
        pars = [b, bc, params[2], params[3]]
        c = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[pars]+args[3:-3]+t_preMAR+args[-3:])
        ax2.plot(c.t, c.y[0],'k-', lw=0.25,alpha=0.2)

    # plot the model forecast with uncertainty
    t_range = [2019.5, 2050]
    args[2] = c.y[0][-1]
   
    # for each random sample solve and plot the forward modelling with each predictor parameter value 
    for b, bc in samples:
        pars = [b, bc, params[2], params[3]]
        args[9] = 0.00
        c_0 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[pars]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.00
        ax2.plot(c_0.t, c_0.y[0],'c-', lw=0.25,alpha=0.2)

        args[9] = 0.02
        c_1 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[pars]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.02
        ax2.plot(c_1.t, c_1.y[0],'g-', lw=0.25,alpha=0.2)
        
        args[9] = 0.05
        c_2 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[pars]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.05
        ax2.plot(c_2.t, c_2.y[0],'r-', lw=0.25,alpha=0.2)
        
        args[9] = 0.075
        c_3 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[pars]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.075
        ax2.plot(c_3.t, c_3.y[0],'b-', lw=0.25,alpha=0.2)
        
        args[9] = 0.1
        c_4 = solve_ivp(ode_model_concentration, t_range, [args[2]], "LSODA", args=[pars]+args[3:-3]+t_preMAR+args[-3:]) # PMAR = 0.1
        ax2.plot(c_4.t, c_4.y[0],'m-', lw=0.25,alpha=0.2)
        

    ax2.plot(c.t, c.y[0], 'k-', label = "nitrate concentration best fit")
    ax2.plot(c_0.t, c_0.y[0], 'c-', label = "PMAR = 0.00")
    ax2.plot(c_1.t, c_1.y[0], 'g-', label = "PMAR = 0.02")
    ax2.plot(c_2.t, c_2.y[0], 'r-', label = "PMAR = 0.05")
    ax2.plot(c_3.t, c_3.y[0], 'b-', label = "PMAR = 0.075")
    ax2.plot(c_4.t, c_4.y[0], 'm-', label = "PMAR = 0.1")
    ax2.axhline(y=8.475, color='k', linestyle=':', label = "Drinking Water Standard (NZDWS)\n 75% of Nitrate-MAV (Maximum Allowable Value)")
    ax1.set_xlabel("time [years]")
    ax1.set_ylabel("no. cows")
    ax2.set_ylabel("nitrate concentration [mg/L]")
    plt.title("Forward Modelling with Uncertainty for Various MAR Schemes")
    ax2.legend(loc='upper left')
    ax1.legend(loc='upper right')
	
    # plot error bars
    v = var
    ax2.errorbar(ts1,lvls,yerr=v,fmt='ro', label='data')
    ax2.legend()
    savePlot = False  # set to True to save the plot as 'uncertainty.png'
    if savePlot:
        plt.savefig('uncertainty.png')   
    else:
        plt.show()

def main():
    b,bc,posterior = grid_search()
    N = 100
    samples = construct_samples(b, bc, posterior, N)
    model_ensemble(samples)


if __name__ == "__main__":
    main()
    
    
    

